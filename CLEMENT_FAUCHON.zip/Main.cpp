//Reversi - Projet 1 de programmation - IMAC 1 (2020-2021)
//par Théo Clément & Margot Fauchon 

#include "Jeu.h"

int main(){
    partie();
    
    return 0;
}